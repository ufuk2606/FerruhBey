
class Seker{
    constructor(id, adi, hacim, birimFiyati){
        this.id= id;
        this.adi = adi;
        this.hacim = hacim;
        this.birimFiyati= birimFiyati;
    }
}