

class Poset{
    constructor(adi, hacim, birimFiyati){
        this.adi= adi ;
        this.hacim = hacim;
        this.birimFiyati = birimFiyati ;
    }
}