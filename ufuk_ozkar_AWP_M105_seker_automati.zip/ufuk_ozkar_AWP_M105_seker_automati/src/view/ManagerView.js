
class ManagerView{

  sekerleriYazdir(){
    let tbodySekerler = sekerDizi.map(item => {return `<tr>
                                                          <td>${item.adi}</td>
                                                          <td>${item.birimFiyati}</td>
                                                          <td>
                                                          <input type="number" value="0" min="0" max="100" id="${item.id}">
                                                          </td>
                                                        </tr>`}).join('');
    document.querySelector("#tbody-sekerler").innerHTML = tbodySekerler ;     
  }

  hesapla(){
    let hesapla = document.querySelector("#hesapla");
    hesapla.addEventListener("click", function(){
      this.toplamHesabiEkranaYazdir();
    }.bind(this));
  }

  toplamHesabiEkranaYazdir(){
    let sekerler = this.sekerleriHesapla();
    let posetler = this.posetleriHesapla();
    document.querySelector("#hesabi-yazdir").innerHTML = sekerler + posetler ;

  }

  sekerleriHesapla(){
    let yuvarlakSekerAdeti = document.querySelector("#yuvarlak").value;
    let yuvarlakSekerinTutari = yuvarlakSekerAdeti * yuvarlakLolipop.birimFiyati ;
    let burguluSekerAdeti = document.querySelector("#burgulu").value;
    let burguluSekerinTutari = burguluSekerAdeti * burguluLolipop.birimFiyati ;
    let jelibonAdeti = document.querySelector("#jelibon").value;
    let jelibonunTutari = jelibonAdeti * jelibon.birimFiyati ;
    let akideSekerininAdeti = document.querySelector("#akide").value;
    let akideSekerininTutari = akideSekerininAdeti * akideSekeri.birimFiyati ;
    let lokumunAdeti = document.querySelector("#lokum").value;
    let lokumunTutari = lokumunAdeti * Lokum.birimFiyati ;
    
    return yuvarlakSekerinTutari + burguluSekerinTutari + jelibonunTutari + akideSekerininTutari + lokumunTutari ;
  }

  posetleriHesapla(){
    let toplamHacim = this.toplamSekerlerinHacmi();
    let kalanHacim = 0 ;
    let kucukPosetAdeti = 0 ;
    let ortaPosetAdeti = 0 ;
    let buyukPosetAdeti = 0 ;
    if (toplamHacim <= 250) {
      kucukPosetAdeti ++ ;
    }else if (toplamHacim <= 400) {
      ortaPosetAdeti ++ ;
    }else if (toplamHacim <= 750) {
      buyukPosetAdeti ++ ;
    }
    else{
      buyukPosetAdeti = Math.floor( toplamHacim / 750 );
      kalanHacim = toplamHacim % 750 ; 
      if (kalanHacim <= 250) {
        kucukPosetAdeti ++ ;
      }else if (kalanHacim <= 400) {
        ortaPosetAdeti ++ ;
      }else if (kalanHacim <= 750) {
        buyukPosetAdeti ++ ;
      }
    }
    return (kucukPosetAdeti * 0.20) + (ortaPosetAdeti * 0.35) + (buyukPosetAdeti * 0.70);
  }

  toplamSekerlerinHacmi(){
    let yuvarlakSekerAdeti = document.querySelector("#yuvarlak").value;
    let yuvarlakSekerinHacmi = yuvarlakSekerAdeti * yuvarlakLolipop.hacim ;
    let burguluSekerAdeti = document.querySelector("#burgulu").value;
    let burguluSekerinHacmi = burguluSekerAdeti * burguluLolipop.hacim ;
    let jelibonAdeti = document.querySelector("#jelibon").value;
    let jelibonunHacmi = jelibonAdeti * jelibon.hacim ;
    let akideSekerininAdeti = document.querySelector("#akide").value;
    let akideSekerininHacmi = akideSekerininAdeti * akideSekeri.hacim ;
    let lokumunAdeti = document.querySelector("#lokum").value;
    let lokumunHacmi = lokumunAdeti * Lokum.hacim ;

    return yuvarlakSekerinHacmi + burguluSekerinHacmi + jelibonunHacmi + akideSekerininHacmi + lokumunHacmi ;
  }

}


