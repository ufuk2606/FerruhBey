
let yuvarlakLolipop = new Seker("yuvarlak", "Yuvarlak Lolipop", 50, 3);
let burguluLolipop = new Seker("burgulu", "Burgulu Lolipop", 20, 2.5);
let jelibon = new Seker("jelibon", "Jelibon", 45, 2.75);
let akideSekeri = new Seker("akide", "Akide Sekeri", 26, 5);
let Lokum = new Seker("lokum", "Lokum", 8, 1.5);

let sekerDizi = [yuvarlakLolipop, burguluLolipop, jelibon, akideSekeri, Lokum];



let kucukPoset = new Poset("kucukPoset", 250, 0.20);
let ortaPoset = new Poset("ortaPoset", 400, 0.35);
let buyukPoset = new Poset("buyukPoset", 750, 0.70);

let managerView = new ManagerView();
managerView.sekerleriYazdir();
managerView.hesapla();




// Manager.sekerleriYazdir(yuvarlakLolipop);
// Manager.sekerleriYazdir(burguluLolipop);
// Manager.sekerleriYazdir(jelibon);
// Manager.sekerleriYazdir(akideSekeri);
// Manager.sekerleriYazdir(Lokum);

// gerek yok
// Manager.posetleriYazdir(kucukPoset);
// Manager.posetleriYazdir(ortaPoset);
// Manager.posetleriYazdir(buyukPoset);

// gerek yok
// Manager.artirButonu(yuvarlakLolipop);
// Manager.artirButonu(burguluLolipop);
// Manager.artirButonu(jelibon);
// Manager.artirButonu(akideSekeri);
// Manager.artirButonu(Lokum);

// gerek yok
// Manager.azaltButonu(yuvarlakLolipop);
// Manager.azaltButonu(burguluLolipop);
// Manager.azaltButonu(jelibon);
// Manager.azaltButonu(akideSekeri);
// Manager.azaltButonu(Lokum);

// gerek yok
// Manager.toplamTutar(yuvarlakLolipop, burguluLolipop, jelibon, akideSekeri, Lokum, kucukPoset, ortaPoset, buyukPoset);
